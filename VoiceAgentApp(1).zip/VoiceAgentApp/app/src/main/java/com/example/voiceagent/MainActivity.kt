package com.example.voiceagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity(), RecognitionListener {

    companion object {
        // Rotate this key in the Groq console once you're done testing — it was shared in plain text.
        const val GROQ_API_KEY = "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"
        const val GROQ_MODEL = "llama-3.3-70b-versatile" // use "llama-3.1-8b-instant" for faster, shorter replies
        const val SYSTEM_PROMPT =
            "You are a helpful, concise voice assistant. Keep replies short (1-3 sentences) since they will be spoken aloud."
        const val REQ_RECORD_AUDIO = 101
    }

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var statusText: TextView
    private lateinit var transcriptText: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var mainButton: Button

    private var running = false
    private var manuallyStopped = true
    private var conversation = mutableListOf<JSONObject>()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        transcriptText = findViewById(R.id.transcriptText)
        scrollView = findViewById(R.id.scrollView)
        mainButton = findViewById(R.id.mainButton)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts.language = Locale.US
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                mainHandler.post {
                    if (running) {
                        setStatus("listening")
                        startListening()
                    }
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post {
                    if (running) {
                        setStatus("listening")
                        startListening()
                    }
                }
            }
        })

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(this)

        mainButton.setOnClickListener { toggle() }
    }

    private fun toggle() {
        if (!running) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_RECORD_AUDIO
                )
                return
            }
            startSession()
        } else {
            stopSession()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSession()
            } else {
                Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startSession() {
        running = true
        manuallyStopped = false
        conversation = mutableListOf(
            JSONObject().put("role", "system").put("content", SYSTEM_PROMPT)
        )
        transcriptText.text = ""
        mainButton.text = "Stop"
        setStatus("listening")
        startListening()
    }

    private fun stopSession() {
        manuallyStopped = true
        running = false
        speechRecognizer.stopListening()
        tts.stop()
        setStatus("idle")
        mainButton.text = "Start"
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try {
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e("VoiceAgent", "startListening failed", e)
        }
    }

    private fun setStatus(state: String) {
        statusText.text = when (state) {
            "listening" -> "Listening…"
            "processing" -> "Thinking…"
            "speaking" -> "Speaking…"
            else -> "Tap start to begin"
        }
    }

    private fun addBubble(who: String, text: String) {
        transcriptText.append("$who: $text\n\n")
        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    // ---- Groq API call (background thread) ----
    private fun askGroq(userText: String) {
        thread {
            try {
                conversation.add(JSONObject().put("role", "user").put("content", userText))

                val messages = JSONArray()
                messages.put(conversation[0]) // system prompt
                val recent = conversation.drop(1).takeLast(10)
                for (m in recent) messages.put(m)

                val body = JSONObject()
                body.put("model", GROQ_MODEL)
                body.put("messages", messages)
                body.put("temperature", 0.6)
                body.put("max_tokens", 300)

                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $GROQ_API_KEY")
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }

                val responseCode = conn.responseCode
                val stream = if (responseCode in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }

                if (responseCode !in 200..299) {
                    throw Exception("Groq error $responseCode: $responseText")
                }

                val json = JSONObject(responseText)
                val reply = json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content").trim()
                conversation.add(JSONObject().put("role", "assistant").put("content", reply))

                mainHandler.post {
                    addBubble("Agent", reply)
                    setStatus("speaking")
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "utt1")
                }
            } catch (e: Exception) {
                Log.e("VoiceAgent", "Groq request failed", e)
                mainHandler.post {
                    addBubble("Agent", "(couldn't reach Groq — check your internet connection)")
                    if (running) {
                        setStatus("listening")
                        startListening()
                    }
                }
            }
        }
    }

    // ---- RecognitionListener callbacks ----
    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val text = matches?.firstOrNull()?.trim()
        if (text.isNullOrEmpty()) {
            if (running) startListening()
            return
        }
        addBubble("You", text)
        setStatus("processing")
        askGroq(text)
    }

    override fun onError(error: Int) {
        // ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT happen often during silence — just retry.
        if (running && !manuallyStopped) {
            mainHandler.postDelayed({ startListening() }, 300)
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
        tts.shutdown()
    }
}
